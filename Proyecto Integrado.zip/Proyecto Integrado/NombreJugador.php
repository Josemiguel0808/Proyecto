<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>WIP</h1>
    <h3>Aqu&iacute ir&aacute un formulario que guardar&aacute en una base de datos los nombres de jugadores antes de empezar la partida</h3>
</body>
</html>